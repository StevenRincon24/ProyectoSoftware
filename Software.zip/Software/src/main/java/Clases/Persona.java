package Clases;

public class Persona {
	private int id_Persona;
    private String nombre_Persona;
    private String apellido_Persona;
    private String email_Persona;

    public int getId_Persona() {
        return id_Persona;
    }

    public void setId_Persona(int id_Persona) {
        this.id_Persona = id_Persona;
    }

    public String getNombre_Persona() {
        return nombre_Persona;
    }

    public void setNombre_Persona(String nombre_Persona) {
        this.nombre_Persona = nombre_Persona;
    }

    public String getApellido_Persona() {
        return apellido_Persona;
    }

    public void setApellido_Persona(String apellido_Persona) {
        this.apellido_Persona = apellido_Persona;
    }

    public String getEmail_Persona() {
        return email_Persona;
    }

    public void setEmail_Persona(String email_Persona) {
        this.email_Persona = email_Persona;
    }

}
